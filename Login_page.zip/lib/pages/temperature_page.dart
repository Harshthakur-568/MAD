import 'package:flutter/material.dart';

class TemperaturePage extends StatefulWidget {
  @override
  _TemperaturePageState createState() => _TemperaturePageState();
}

class _TemperaturePageState extends State<TemperaturePage> {
  final TextEditingController _celsiusController = TextEditingController();
  String result = "";

  void convert() {
    double celsius = double.tryParse(_celsiusController.text) ?? 0;
    double fahrenheit = (celsius * 9 / 5) + 32;
    setState(() {
      result = "$celsius°C = ${fahrenheit.toStringAsFixed(2)}°F";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Temperature Converter")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            controller: _celsiusController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: "Enter Celsius"),
          ),
          SizedBox(height: 10),
          ElevatedButton(onPressed: convert, child: Text("Convert")),
          SizedBox(height: 20),
          Text(result, style: TextStyle(fontSize: 20)),
        ]),
      ),
    );
  }
}
