import 'package:flutter/material.dart';

class SecondScreen extends StatelessWidget {
  final String name;
  final String gender;
  final String dob;
  final String address;
  final String city;
  final String pincode;

  SecondScreen({
    required this.name,
    required this.gender,
    required this.dob,
    required this.address,
    required this.city,
    required this.pincode,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('All details')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Name: $name', style: TextStyle(fontSize: 18)),
            Text('Gender: $gender', style: TextStyle(fontSize: 18)),
            Text('DOB: $dob', style: TextStyle(fontSize: 18)),
            Text('Address: $address', style: TextStyle(fontSize: 18)),
            Text('City: $city', style: TextStyle(fontSize: 18)),
            Text('Pin Code: $pincode', style: TextStyle(fontSize: 18)),
            SizedBox(height: 30),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('BACK'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
