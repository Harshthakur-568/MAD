import 'package:flutter/material.dart';
import 'dart:math';

class AgePage extends StatefulWidget {
  @override
  _AgePageState createState() => _AgePageState();
}

class _AgePageState extends State<AgePage> {
  final TextEditingController _yearController = TextEditingController();
  String result = "";

  void calculateAge() {
    int birthYear = int.tryParse(_yearController.text) ?? 0;
    int currentYear = DateTime.now().year;
    int age = max(0, currentYear - birthYear);
    setState(() {
      result = "You are $age years old.";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Age Calculator")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            controller: _yearController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: "Enter Birth Year"),
          ),
          SizedBox(height: 10),
          ElevatedButton(onPressed: calculateAge, child: Text("Calculate Age")),
          SizedBox(height: 20),
          Text(result, style: TextStyle(fontSize: 20)),
        ]),
      ),
    );
  }
}
