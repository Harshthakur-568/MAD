import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: BookListScreen()));

class BookListScreen extends StatelessWidget {
  final List<Map<String, String>> books = [
    {
      "title": "The Alchemist",
      "author": "Paulo Coelho",
      "image": "https://via.placeholder.com/50"
    },
    {
      "title": "1984",
      "author": "George Orwell",
      "image": "https://via.placeholder.com/50"
    },
    {
      "title": "To Kill a Mockingbird",
      "author": "Harper Lee",
      "image": "https://via.placeholder.com/50"
    },
    {
      "title": "The Great Gatsby",
      "author": "F. Scott Fitzgerald",
      "image": "https://via.placeholder.com/50"
    },
    {
      "title": "Pride and Prejudice",
      "author": "Jane Austen",
      "image": "https://via.placeholder.com/50"
    },
    {
      "title": "Moby-Dick",
      "author": "Herman Melville",
      "image": "https://via.placeholder.com/50"
    },
    {
      "title": "The Hobbit",
      "author": "J.R.R. Tolkien",
      "image": "https://via.placeholder.com/50"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Book List")),
      body: ListView.builder(
        itemCount: books.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(8),
            elevation: 4,
            child: ListTile(
              leading: Image.network(
                books[index]['image']!,
                width: 50,
                height: 50,
              ),
              title: Text(books[index]['title']!),
              subtitle: Text("Author: ${books[index]['author']}"),
            ),
          );
        },
      ),
    );
  }
}
