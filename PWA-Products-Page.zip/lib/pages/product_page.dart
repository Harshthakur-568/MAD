import 'package:flutter/material.dart';

class ProductPage extends StatelessWidget {
  final List<Map<String, dynamic>> products = [
    {
      'name': 'Laptop',
      'price': 55000,
      'quantity': 10,
      'image': 'https://via.placeholder.com/100'
    },
    {
      'name': 'Phone',
      'price': 30000,
      'quantity': 25,
      'image': 'https://via.placeholder.com/100'
    },
    {
      'name': 'Headphones',
      'price': 1500,
      'quantity': 50,
      'image': 'https://via.placeholder.com/100'
    },
    {
      'name': 'Monitor',
      'price': 7000,
      'quantity': 15,
      'image': 'https://via.placeholder.com/100'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Product Page')),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          var item = products[index];
          return ListTile(
            leading: Image.network(item['image']),
            title: Text(item['name']),
            subtitle:
                Text('Price: ₹${item['price']}, Qty: ${item['quantity']}'),
          );
        },
      ),
    );
  }
}
