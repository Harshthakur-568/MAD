import 'package:flutter/material.dart';
import 'pages/calculator_app.dart'; // Make sure this import is correct

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Calculator',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: CalculatorApp(), // Correct usage of CalculatorApp
      debugShowCheckedModeBanner: false,
    );
  }
}
