import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: MarksForm()));

class MarksForm extends StatefulWidget {
  @override
  _MarksFormState createState() => _MarksFormState();
}

class _MarksFormState extends State<MarksForm> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController markController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();

  String? validatePositiveNumber(String? value) {
    if (value == null || value.isEmpty) return 'Field is required';
    final number = double.tryParse(value);
    if (number == null || number < 0) return 'Enter a positive number';
    return null;
  }

  String? validateTextOnly(String? value) {
    if (value == null || value.isEmpty) return 'Field is required';
    if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(value)) {
      return 'Only letters are allowed';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Marks Validation")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: markController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Marks'),
                validator: validatePositiveNumber,
              ),
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Name'),
                validator: validateTextOnly,
              ),
              TextFormField(
                controller: subjectController,
                decoration: InputDecoration(labelText: 'Subject'),
                validator: validateTextOnly,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Valid input!')),
                    );
                  }
                },
                child: Text("Submit"),
              )
            ],
          ),
        ),
      ),
    );
  }
}
