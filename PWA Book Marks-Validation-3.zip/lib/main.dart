import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: BookWebPage()));

class BookWebPage extends StatelessWidget {
  final List<Map<String, String>> books = [
    {
      "title": "The Silent Patient",
      "author": "Alex Michaelides",
      "image": "https://via.placeholder.com/100"
    },
    {
      "title": "Becoming",
      "author": "Michelle Obama",
      "image": "https://via.placeholder.com/100"
    },
    {
      "title": "Educated",
      "author": "Tara Westover",
      "image": "https://via.placeholder.com/100"
    },
    {
      "title": "Atomic Habits",
      "author": "James Clear",
      "image": "https://via.placeholder.com/100"
    },
    {
      "title": "The Subtle Art of Not Giving a F*ck",
      "author": "Mark Manson",
      "image": "https://via.placeholder.com/100"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Books (PWA)")),
      body: ListView.builder(
        itemCount: books.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(12),
            child: ListTile(
              leading: Image.network(books[index]['image']!),
              title: Text(books[index]['title']!),
              subtitle: Text("Author: ${books[index]['author']}"),
            ),
          );
        },
      ),
    );
  }
}
