import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
      home: FirstScreen(),
    ));

class UserData {
  String name = '';
  String mobile = '';
  String address = '';
  String city = '';
}

// First Screen
class FirstScreen extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final UserData data = UserData();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Step 1")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(children: [
            TextFormField(
              controller: nameController,
              decoration: InputDecoration(labelText: "Name"),
              validator: (val) => val!.isEmpty ? 'Required' : null,
            ),
            TextFormField(
              controller: mobileController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(labelText: "Mobile Number"),
              validator: (val) => val!.isEmpty ? 'Required' : null,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  data.name = nameController.text;
                  data.mobile = mobileController.text;
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SecondScreen(data: data),
                    ),
                  );
                }
              },
              child: Text("Next"),
            )
          ]),
        ),
      ),
    );
  }
}

// Second Screen
class SecondScreen extends StatelessWidget {
  final UserData data;

  SecondScreen({required this.data});

  final TextEditingController addressController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Step 2")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(children: [
            TextFormField(
              controller: addressController,
              decoration: InputDecoration(labelText: "Address"),
              validator: (val) => val!.isEmpty ? 'Required' : null,
            ),
            TextFormField(
              controller: cityController,
              decoration: InputDecoration(labelText: "City"),
              validator: (val) => val!.isEmpty ? 'Required' : null,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  data.address = addressController.text;
                  data.city = cityController.text;
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FinalScreen(data: data),
                    ),
                  );
                }
              },
              child: Text("Next"),
            )
          ]),
        ),
      ),
    );
  }
}

// Third Screen (Final)
class FinalScreen extends StatelessWidget {
  final UserData data;

  FinalScreen({required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Final Details")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Name: ${data.name}"),
            Text("Mobile: ${data.mobile}"),
            Text("Address: ${data.address}"),
            Text("City: ${data.city}"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Back"),
            ),
          ],
        ),
      ),
    );
  }
}
